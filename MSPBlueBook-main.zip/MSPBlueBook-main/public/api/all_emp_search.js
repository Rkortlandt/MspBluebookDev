  //get users from db
  document.readyState = getUsers();
function getUsers(){
var textURL = "https://mspbluebook.co/active_search_employee";
fetch(textURL)
.then( async function(response) {
//use the json() method to extract the json from the response
var resjs = await response.json();
return resjs;
})
.then(function(resjs) {
var table = document.getElementById("table");

for (let i = 0; i < resjs.length; i++) {
    var row = table.insertRow(i+1);
    var name_cell = document.createElement("td");
    var id_cell = document.createElement("td");
    var name_text = document.createTextNode(resjs[i].employee_ln + ", " + resjs[i].employee_fn);
    var id_text = document.createTextNode(resjs[i].employee_email);
    name_cell.appendChild(name_text);
    id_cell.appendChild(id_text);
    row.appendChild(name_cell);
    row.appendChild(id_cell);
    //add event listener to each row
    row.addEventListener("click", function(){
    //redirect to employee page
    alert("You will be redirected to the employee page. You clicked employee number: "+resjs[i].employee_num);
    window.location.href = "https://mspbluebook.co/dash?employee_num=" + resjs[i].employee_num;
    }
);
}
})

.catch(err => { console.log(err) });
}
