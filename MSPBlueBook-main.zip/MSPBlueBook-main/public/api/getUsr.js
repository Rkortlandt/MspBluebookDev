function getUser(){
  var textURL = "https://mspbluebook.co/profile";
//Option with catch
  fetch( textURL )
    .then(async r=> document.getElementById("topbar_nav--login").innerHTML = "Welcome, " + (JSON.parse(await r.text()).nickname))
    .catch(e=>console.error('Boo...' + e));   
  }