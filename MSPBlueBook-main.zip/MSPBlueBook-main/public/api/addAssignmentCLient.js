var textURL = "https://mspbluebook.co/active_search_employee";
fetch(textURL)
.then( async function(response) {
//use the json() method to extract the json from the response
var resjs = await response.json();
return resjs;
})
.then(function(resjs) {
var table = document.getElementById("table");

for (let i = 0; i < resjs.length; i++) {
    
}})

function addAssignmentClient(){
  Swal.mixin({
    confirmButtonText: 'Next →',
    showCancelButton: true,
    progressSteps: ['1', '2', '3', '4']
  }).queue([
    {
      input: 'email',
      title: 'Add Assignment',
      text: 'Enter employee email'
    },
    {
      text: 'Select assignment',
      input: 'select',
      inputOptions: {

      }
  },
  {
    text: 'Select due date',
    input: 'date',
  },
    'Is this a critical assignment?'
  ]).then((result) => {
    if (result.value) {
      const answers = JSON.stringify(result.value)
      Swal.fire({
        title: 'All done!',
        html: `
          Your answers:
          <pre><code>${answers}</code></pre>
        `,
        confirmButtonText: 'Lovely!'
      })
    }
  })
}