const rateLimit = require('express-rate-limit');
const express = require('express');
const app = express();
//Stop brute force/spam attacks
function indexLimiter() {
    return rateLimit({
        windowMs: 8 * 60 * 1000, // 5 minutes
        max: 200, // Limit each IP to 100 requests per `window`
        standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
        legacyHeaders: false, // Disable the `X-RateLimit-*` headers
    });
}

//ratelimiter for full page
function limiter() {
    return rateLimit({
        windowMs: 5 * 60 * 1000, // 5 minutes
        max: 700, // Limit each IP to 100 requests per `window`
        standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
        legacyHeaders: false, // Disable the `X-RateLimit-*` headers
    });
}

//Set request size limit
function appRequestSizeLimiter() {
app.use(function (req, res, next) {
    if (!['POST', 'PUT', 'DELETE'].includes(req.method)) {
      next()
      return
    }
  
    getRawBody(req, {
      length: req.headers['content-length'],
      limit: '5kb',
      encoding: contentType.parse(req).parameters.charset
    }, function (err, string) {
      if (err) return next(err)
      req.text = string
      next()
    })
  })
};

module.exports = { appRequestSizeLimiter, limiter , indexLimiter};