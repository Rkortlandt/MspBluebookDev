//IMPORTS
const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const port = process.env.PORT || 80;
const { auth } = require('express-openid-connect');
const { requiresAuth } = require('express-openid-connect');
const { fileURLToPath } = require('url');
const ip = require('ip');
const https = require('https')
const mysql = require('mysql');
const url = require('url');
const queryString = require('query-string');
const contentType = require('content-type')
const getRawBody = require('raw-body')
var SqlString = require('sqlstring');
const rateLimit = require('express-rate-limit');
var cookieParser = require('cookie-parser')
var db = require('./database.js');
var sec = require('./security.js');
const req = require('express/lib/request');
const { json } = require('express/lib/response');
const met = require('prom-client');
const sqlstring = require('sqlstring');

//metrics

// Create a Registry which registers the metrics
const register = new met.Registry()

register.setDefaultLabels({
  app: 'mspbluebook'
})
met.collectDefaultMetrics({ register })

//https settings
const httpsOptions = {
cert: fs.readFileSync('./mspbluebook_co.crt'),
ca: fs.readFileSync('./mspbluebook_co.ca-bundle'),
key: fs.readFileSync('./mspbluebook_co.key')
}
const httpsServer = https.createServer(httpsOptions, app);

//for login
const config = {
  authRequired: false,
  auth0Logout: true,
  secret: 'y8gQ8NZr7jFU-RAvvFzfF26J1ZeK3oDQBkcgf_niGztfD5tccK85ZBQZFxBb0fl4',
  baseURL: 'https://mspbluebook.co',
  clientID: 'BFqWvgUeYp0wAn2zamZlSTVZGmTgcI7t',
  issuerBaseURL: 'https://mspbluebook.us.auth0.com',
};

// auth router attaches /login, /logout, and /callback routes to the baseURL
app.use(auth(config));

//SECURITY SETTINGS

//Stop brute force/spam attacks

 //sanitize user input
var root = '/public/';
exports.validatePath = (user_input) => {
if (user_input.indexOf('\0') !== -1) {
return 'Access denied';
}
if (!/^[a-z0-9]+$/.test(user_input)) {
return 'Access denied';
}
var path = require('path');
var safe_input = path.normalize(user_input).replace(/^(\.\.(\/|\\|$))+/, '');
var path_string = path.join(root, safe_input);
if (path_string.indexOf(root) !== 0) {
return 'Access denied';
}
return path_string;
}

//Apply to index page
app.use('/', sec.indexLimiter());

// Apply the rate limiting middleware to all requests
app.use('/dash/',sec.limiter());
app.use('/img/',sec.limiter());

//apply req size limit
sec.appRequestSizeLimiter();
//Set JSON request size limit
app.use(express.json({ limit: "10kb" }));

//Use anti CORS cookies
app.use(cookieParser());

// req.isAuthenticated is provided from the auth router
app.get('/status.html', (req, res) => {
  res.send(req.oidc.isAuthenticated() ? 'Logged in' : 'Logged out');
});

app.get('/profile', requiresAuth(), (req, res) => {
  res.send(JSON.stringify(req.oidc.user));
});

app.use((req, res, next) => {
  if(req.protocol === 'http') {
    res.redirect(301, `https://${req.headers.host}${req.url}`);
  }
  next();
});


//host main page (no auth)
app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, '/public/index.html'));
});

//host required assets for main page
app.get('/style.css', function(req, res) {
  res.sendFile(path.join(__dirname, '/public/style.css'));
});
app.get('/img/LogoXL.webp', function(req, res) {
  res.sendFile(path.join(__dirname, '/public/img/LogoXL.webp'));
});
app.get('/img/Banner3.webp', function(req, res) {
  res.sendFile(path.join(__dirname, '/public/img/Banner3.webp'));
});


//host all other pages (auth)
app.use('/', requiresAuth(), express.static('public/'));

app.listen(80, () => console.log('\x1b[33m%s\x1b[0m',`[SERVER] Listening for HTTP requests on port ${port}!`));

//https listen

httpsServer.listen(443), () => console.log('\x1b[33m%s\x1b[0m',`[SERVER] Listening for HTTPS requests on port ${port}!`);

//GET IP ADDR
var addr = ip.address();

console.log('\x1b[33m%s\x1b[0m','[SERVER] Server started at IP:'+addr+' PORT:'+ '443 & 80');

//mysql connection

//test connection
db.testDatabaseConnection();

//monitor for mySQL forum requests
//EXAMPLE REQUEST: https://mspbluebook.co/status_main?employee_num=123432&employee_name=Test&assignment=Testfromurl&due_date=2023-01-01&is_critical=1&is_repeating=0&is_done=1&completion_date=2022-01-01
app.get('/add_assign_status_main', requiresAuth(), (req, res) => {
  var employee_email = req.query.employee_email;
  //var assignment = req.query.assignment;
  var due_date = req.query.due_date;
  var is_critical = req.query.is_critical;
  var is_repeating = req.query.is_repeating;
//if is_critical is on, set its value to 1
  if (is_critical == 'true') {
    is_critical = 1;
  } else {
    is_critical = 0;
  }
//if is_repeating is on, set its value to 1
  if (is_repeating == 'true') {
    is_repeating = 1;
  } else {
    is_repeating = 0;
  }

  //ensure that all fields are filled out
  if (employee_email == null || due_date == null || is_critical == null || is_repeating == null) {
    console.log('\x1b[36m%s\x1b[0m','[SQL] Error at /add_assign_status_main: Missing parameters');
    res.send('<h1>Error: Missing parameters</h1>');
  } else {
  console.log('\x1b[36m%s\x1b[0m',"[SQL] Data written to status_main table: "+employee_email, due_date, is_critical, is_repeating);
  db.AddAssignment(employee_email, due_date, is_critical, is_repeating);
  res.redirect('/dash/admin/form.html');
  }
});

//active search for employee table
app.get('/active_search_employee', requiresAuth(), (req, res) => {
//send data from database to client
db.queryDatabase('SELECT * FROM employees', function(response){
  //make json
//console.log('\x1b[36m%s\x1b[0m',"[SQL] [DEBUG] Data sent to client for employee search: "+JSON.stringify(response));
res.send(JSON.stringify(response));
  });
});

app.get('/api/v_assignments', requiresAuth(), (req, res) => {
  //send data from database to client
  db.queryDatabase('SELECT course_title, course_id FROM courses', function(response){
  //make json
  //console.log('\x1b[36m%s\x1b[0m',"[SQL] [DEBUG] Data sent to client for add assignment: "+JSON.stringify(response));
  res.send(JSON.stringify(response));
  });
  });


app.get('/get_all_assignments', requiresAuth(), (req, res) => {
//send data from database to client
db.queryDatabase('SELECT * FROM status_main', function(response){
  //make json
//console.log('\x1b[36m%s\x1b[0m',"[SQL] [DEBUG] Data sent to client for employee search: "+JSON.stringify(response));
res.send(JSON.stringify(response));
});
});
//EMAIL MUST BE IN STRING FORMAT
app.get('/get_per_assignments', requiresAuth(), (req, res) => {
  //send data from database to client
  db.queryDatabase("SELECT * FROM status_main WHERE employee_email = "+ sqlstring.escape(req.query.employee_email), function(response){
    //make json
  //console.log('\x1b[36m%s\x1b[0m',"[SQL] [DEBUG] Data sent to client for employee search: "+JSON.stringify(response));
  res.send(JSON.stringify(response));
  });
  });

//metrics for grafana
app.get('/metrics', async (_req, res) => {
  try {
    res.set('Content-Type', register.contentType);
    res.end(await register.metrics());
  } catch (err) {
    res.status(500).end(err);
  }
});


//404 (ANY REQUESTS AFTER THIS WILL RETURN 404)

app.use(function(req, res, next) {
  res.status(404).sendFile(path.join(__dirname, '/public/404.html'));
});




