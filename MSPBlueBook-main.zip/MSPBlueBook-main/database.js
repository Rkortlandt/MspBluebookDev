const mysql = require('mysql');
var SqlString = require('sqlstring');

function connectToDatabase() {
    status_main_connection = mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: 'T6^n3Pv$',
      database: 'status-mspbluebook'
    });
    return status_main_connection;
  }

//function that tests database connection
function testDatabaseConnection() {
    console.log('\x1b[36m%s\x1b[0m',"[SQL] Testing database connection...");
    connectToDatabase();
    status_main_connection.connect(function(err) {
      if (err) { 
      console.log('\x1b[36m%s\x1b[0m',"[SQL]",'\u001b[31mm%s\x1b[0m', 'Failed to connect to database!');
      throw err;
      } else {
      console.log('\x1b[36m%s\x1b[0m',"[SQL] Connected to database!");
      }
    });
  }
  
  //function that queries database
  function queryDatabase(query, callback) {
  connectToDatabase();
  status_main_connection.connect(function(err) {
    if (err) throw err;
    console.log('\x1b[36m%s\x1b[0m',"[SQL] Sending query to database...");
    //query database
    status_main_connection.query(query, function (err, result) {
      if (err) throw err;
      console.log('\x1b[36m%s\x1b[0m',"[SQL] Query successful!");
      return callback(result);
    });
  });
  }

function AddAssignment(employee_email, due_date, is_critical, is_repeating){
    connectToDatabase();
    status_main_connection.connect(function(err) {
    if (err) throw err;
    //ESCAPE USER VAIABLES
    var UserDat = SqlString.format("INSERT INTO status_main (employee_email, due_date, is_critical, is_repeating) VALUES (?, ?, ?, ?)", [employee_email, due_date, is_critical, is_repeating]);
    status_main_connection.query(UserDat), function (err, result) {
    if (err) throw err;
    console.log('\x1b[36m%s\x1b[0m','[SQL] Finished adding assignment to status_main');
    console.log('\x1b[36m%s\x1b[0m','[SQL] Escaped MySQL variables and ran command: '+UserDat.toString());
    };
  })};

  function GetAssignments(employee_email){
    connectToDatabase();
    status_main_connection.connect(function(err) {
    if (err) throw err;
    //ESCAPE USER VAIABLES
    var UserDat = SqlString.format("SELECT * FROM status_main WHERE employee_email = ?", [employee_email]);
    status_main_connection.query(UserDat), function (err, result) {
    if (err) throw err;
    console.log('\x1b[36m%s\x1b[0m','[SQL] Finished getting assignments from status_main');
    console.log('\x1b[36m%s\x1b[0m','[SQL] Escaped MySQL variables and ran command: '+UserDat.toString());
    };
  })};

  module.exports = { GetAssignments ,AddAssignment, queryDatabase, testDatabaseConnection };

  
